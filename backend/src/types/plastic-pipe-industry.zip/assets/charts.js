(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart 1: Market Size Trend ---
  var chart1 = echarts.init(document.getElementById('chart-market-size'), null, { renderer: 'svg' });
  chart1.setOption({
    animation: false,
    color: [accent, accent2],
    tooltip: { trigger: 'axis', appendToBody: true },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '8%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['2021', '2022', '2023', '2024', '2025', '2026E', '2027E', '2028E', '2029E', '2030E'],
      axisLabel: { color: muted },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '亿元',
      axisLabel: { color: muted },
      axisLine: { show: false },
      splitLine: { lineStyle: { color: rule } },
      min: 1500
    },
    series: [{
      name: '市场规模',
      type: 'bar',
      barWidth: 22,
      data: [1800, 1950, 2100, 2280, 2490, 2660, 2840, 3020, 3220, 3500],
      itemStyle: { borderRadius: [4, 4, 0, 0] },
      label: { show: true, position: 'top', color: muted, fontSize: 10 }
    }, {
      name: '同比增速',
      type: 'line',
      yAxisIndex: 1,
      data: [null, 8.3, 7.7, 8.6, 9.2, 6.8, 6.8, 6.3, 6.6, 8.7],
      lineStyle: { color: accent2, width: 2.5 },
      itemStyle: { color: accent2 },
      symbol: 'circle',
      symbolSize: 6,
      label: { show: true, position: 'top', color: accent2, fontSize: 10, formatter: '{c}%' }
    }],
    legend: { data: ['市场规模（亿元）', '同比增长率'], textStyle: { color: muted }, top: 0 }
  });
  window.addEventListener('resize', function() { chart1.resize(); });

  // --- Chart 2: Product Structure Pie ---
  var chart2 = echarts.init(document.getElementById('chart-product-structure'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    color: [accent, accent2, muted, accent + '99'],
    tooltip: { trigger: 'item', formatter: '{b}: {c}%', appendToBody: true },
    series: [{
      type: 'pie',
      radius: ['45%', '75%'],
      center: ['50%', '50%'],
      label: { formatter: '{b}\n{d}%', color: ink },
      data: [
        { value: 45, name: 'PVC管' },
        { value: 36, name: 'PE管' },
        { value: 18, name: 'PPR管' },
        { value: 1, name: '复合/特种管' }
      ],
      emphasis: {
        label: { fontSize: 16, fontWeight: 'bold' }
      }
    }]
  });
  window.addEventListener('resize', function() { chart2.resize(); });

  // --- Chart 3: CR5 Trend ---
  var chart3 = echarts.init(document.getElementById('chart-cr5'), null, { renderer: 'svg' });
  chart3.setOption({
    animation: false,
    color: [accent],
    tooltip: { trigger: 'axis', appendToBody: true },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '8%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['2020', '2021', '2022', '2023', '2024', '2025'],
      axisLabel: { color: muted },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '%',
      min: 20,
      max: 45,
      axisLabel: { color: muted },
      axisLine: { show: false },
      splitLine: { lineStyle: { color: rule } }
    },
    series: [{
      name: 'CR5市占率',
      type: 'line',
      data: [24.5, 26.8, 29.1, 31.5, 34.1, 37.8],
      smooth: true,
      lineStyle: { color: accent, width: 3 },
      itemStyle: { color: accent },
      symbol: 'circle',
      symbolSize: 8,
      areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: accent + '40' }, { offset: 1, color: accent + '05' }] } },
      markLine: {
        silent: true,
        data: [{ yAxis: 30, label: { formatter: '30% 门槛', color: muted, fontSize: 11 }, lineStyle: { color: accent2, type: 'dashed' } }]
      },
      label: { show: true, color: accent, fontSize: 11, formatter: '{c}%', offset: [0, 8] }
    }]
  });
  window.addEventListener('resize', function() { chart3.resize(); });

  // --- Chart 4: Revenue vs Gross Margin Compare ---
  var chart4 = echarts.init(document.getElementById('chart-revenue-compare'), null, { renderer: 'svg' });
  chart4.setOption({
    animation: false,
    color: [accent, accent2],
    tooltip: { trigger: 'axis', appendToBody: true },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '8%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['中国联塑', '公元股份', '伟星新材'],
      axisLabel: { color: muted, fontSize: 12, fontWeight: 'bold' },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: [{
      type: 'value',
      name: '营收（亿元）',
      axisLabel: { color: muted },
      axisLine: { show: false },
      splitLine: { lineStyle: { color: rule } }
    }, {
      type: 'value',
      name: '毛利率（%）',
      min: 0,
      max: 50,
      axisLabel: { color: muted },
      axisLine: { show: false },
      splitLine: { show: false }
    }],
    series: [{
      name: '2025年营收',
      type: 'bar',
      barWidth: 40,
      data: [243.15, 61.76, 53.82],
      itemStyle: {
        borderRadius: [4, 4, 0, 0],
        color: accent
      },
      label: { show: true, position: 'top', color: accent, fontSize: 11, fontWeight: 'bold', formatter: '{c}亿' }
    }, {
      name: '毛利率',
      type: 'line',
      yAxisIndex: 1,
      data: [27.5, 18.0, 40.0],
      lineStyle: { color: accent2, width: 3 },
      itemStyle: { color: accent2 },
      symbol: 'diamond',
      symbolSize: 12,
      label: { show: true, position: 'top', color: accent2, fontSize: 11, fontWeight: 'bold', formatter: '{c}%' }
    }],
    legend: { data: ['营收（亿元）', '毛利率（%）'], textStyle: { color: muted }, top: 0 }
  });
  window.addEventListener('resize', function() { chart4.resize(); });

  // --- Chart 5: Demand Structure Pie ---
  var chart5 = echarts.init(document.getElementById('chart-demand-structure'), null, { renderer: 'svg' });
  chart5.setOption({
    animation: false,
    color: [accent, accent2, accent + '99', accent2 + '99'],
    tooltip: { trigger: 'item', formatter: '{b}: {c}%', appendToBody: true },
    series: [{
      type: 'pie',
      radius: ['45%', '75%'],
      center: ['50%', '50%'],
      label: { formatter: '{b}\n占比 {d}%', color: ink },
      data: [
        { value: 53, name: '建筑给排水' },
        { value: 35, name: '市政工程' },
        { value: 9, name: '农业灌溉' },
        { value: 3, name: '工业/燃气/其他' }
      ],
      emphasis: {
        label: { fontSize: 16, fontWeight: 'bold' }
      }
    }]
  });
  window.addEventListener('resize', function() { chart5.resize(); });

  // --- Chart 6: Market Share Pie ---
  var chart6 = echarts.init(document.getElementById('chart-market-share'), null, { renderer: 'svg' });
  chart6.setOption({
    animation: false,
    color: [accent, accent2, accent + '99', accent2 + '99'],
    tooltip: { trigger: 'item', formatter: '{b}: {c}%', appendToBody: true },
    series: [{
      type: 'pie',
      radius: ['45%', '75%'],
      center: ['50%', '50%'],
      label: { formatter: '{b}\n{d}%', color: ink },
      data: [
        { value: 12.4, name: '中国联塑' },
        { value: 3.5, name: '公元股份' },
        { value: 3.1, name: '伟星新材' },
        { value: 81.0, name: '其他企业' }
      ],
      emphasis: { label: { fontSize: 16, fontWeight: 'bold' } }
    }]
  });
  window.addEventListener('resize', function() { chart6.resize(); });

  // --- Chart 7: Raw Material Price Trend ---
  var chart7 = echarts.init(document.getElementById('chart-raw-price'), null, { renderer: 'svg' });
  chart7.setOption({
    animation: false,
    color: [accent, accent2, muted],
    tooltip: { trigger: 'axis', appendToBody: true },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '8%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['2023Q1', '2023Q2', '2023Q3', '2023Q4', '2024Q1', '2024Q2', '2024Q3', '2024Q4', '2025Q1', '2025Q2', '2025Q3', '2025Q4'],
      axisLabel: { color: muted, fontSize: 10 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '元/吨',
      min: 5500,
      axisLabel: { color: muted },
      axisLine: { show: false },
      splitLine: { lineStyle: { color: rule } }
    },
    series: [
      {
        name: 'PVC树脂',
        type: 'line',
        data: [6200, 6400, 6800, 6600, 6300, 6500, 6700, 6400, 6300, 6600, 6500, 6500],
        lineStyle: { color: accent, width: 2.5 },
        itemStyle: { color: accent },
        symbol: 'circle',
        symbolSize: 5
      },
      {
        name: 'PE树脂',
        type: 'line',
        data: [8800, 8600, 8500, 8400, 8600, 8400, 8300, 8200, 8300, 8100, 8200, 8200],
        lineStyle: { color: accent2, width: 2.5 },
        itemStyle: { color: accent2 },
        symbol: 'circle',
        symbolSize: 5
      },
      {
        name: 'PP树脂',
        type: 'line',
        data: [8700, 8600, 8500, 8600, 8700, 8600, 8400, 8500, 8600, 8500, 8400, 8500],
        lineStyle: { color: muted, width: 2.5, type: 'dashed' },
        itemStyle: { color: muted },
        symbol: 'circle',
        symbolSize: 5
      }
    ],
    legend: { data: ['PVC树脂', 'PE树脂', 'PP树脂'], textStyle: { color: muted }, top: 0 }
  });
  window.addEventListener('resize', function() { chart7.resize(); });

  // --- Chart 8: Product Gross Margin ---
  var chart8 = echarts.init(document.getElementById('chart-margin'), null, { renderer: 'svg' });
  chart8.setOption({
    animation: false,
    color: [accent],
    tooltip: { trigger: 'axis', appendToBody: true, formatter: '{b}: {c}%' },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '5%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['PVC排水管', '普通PPR管', 'PE给水管', 'PE燃气管', '钢塑复合管', '再生PE管材'],
      axisLabel: { color: muted, fontSize: 10 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '%',
      min: 0,
      max: 55,
      axisLabel: { color: muted },
      axisLine: { show: false },
      splitLine: { lineStyle: { color: rule } }
    },
    series: [{
      name: '毛利率',
      type: 'bar',
      barWidth: 32,
      data: [
        { value: 12, itemStyle: { color: muted } },
        { value: 18, itemStyle: { color: accent + '99' } },
        { value: 22, itemStyle: { color: accent } },
        { value: 35, itemStyle: { color: accent2 } },
        { value: 42, itemStyle: { color: accent2 } },
        { value: 28, itemStyle: { color: accent } }
      ],
      itemStyle: { borderRadius: [4, 4, 0, 0] },
      label: { show: true, position: 'top', color: muted, fontSize: 11, formatter: '{c}%' }
    }]
  });
  window.addEventListener('resize', function() { chart8.resize(); });

})();